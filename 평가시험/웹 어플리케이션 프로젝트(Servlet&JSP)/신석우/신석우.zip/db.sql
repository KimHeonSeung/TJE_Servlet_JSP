create database recipeSite;
use recipeSite;

-- 회원 테이블
create table member(
	member_id varchar(20) primary key,
    password varchar(20) not null,
    nickname varchar(20) not null unique,
    email varchar(30) not null unique,
    regist_date date not null,
    last_access_time timestamp
);

-- 레시피 테이블
create table recipe(
	recipe_id int auto_increment primary key,
    member_id varchar(20),
    category varchar(20) not null,
    title varchar(100) not null,
    content varchar(1000) not null,
    write_time timestamp not null,
    last_update_time timestamp not null,
    read_count int not null,
    like_count int not null,
    foreign key(member_id) references member(member_id)
);

-- 댓글 테이블
create table comment (
	comment_id int auto_increment primary key,
    recipe_id int,
    member_id varchar(20),
    content varchar(1000) not null,
    write_time timestamp not null,
    foreign key(recipe_id) 
		references recipe(recipe_id)
        on delete cascade,
    foreign key(member_id) 
		references member(member_id)
);

-- 좋아요 중복확인
create table thumbsup(
	recipe_id int not null,
    member_id varchar(20) not null,
    primary key(recipe_id,member_id),
        foreign key(recipe_id) 
		references recipe(recipe_id),
    foreign key(member_id) 
		references member(member_id)
);

-- 리스트용
create view simpleRecipe
as
select a.recipe_id, a.member_id, a.category, a.title, m.nickname, a.write_time, a.read_count , a.like_count
from recipe a inner Join member m
on a.member_id = m.member_id;












select * from member;
select * from recipe;
select * from comment;
drop table recipe;
drop table comment;
desc recipe;
update member set password = "password" , nickname = "helloman" , email = "modify@modify.com"  where member_id = "a5";
insert into recipe values (null, "12341234","1234","7","asdf",now(),now(),0,0);
select * from recipe order by write_time desc;
select last_insert_id();


drop view simpleRecipe;
select * from simpleRecipe;
select * from simpleRecipe where category="1234" order by write_time asc;
select * from simpleRecipe order by write_time desc;



truncate thumbsUp;
drop table thumbsup;
select * from thumbsUp;
 
insert into thumbsUp values (34,'3sss');
insert into thumbsUp values (2,'12341234');
insert into thumbsUp values (2,'3sss');
insert into thumbsUp values (1,'12341234');
insert into thumbsUp values (3,'3sss');
insert into thumbsUp values (4,'3sss');
select count(*) from thumbsup where recipe_id=4 and member_id='3ssss';
update recipe set like_count = like_count +1 where recipe_id = 34;
update recipe set like_count = like_count -1 where recipe_id = 1;
delete from thumbsUp where recipe_id=4 and member_id='3sss';
select * from thumbsUp;
truncate thumbsUp;
update recipe set like_count = 0;
select * from recipe;
select * from simplerecipe;
select * from thumbsup;
select * from member;
select * from comment;
-- =================================================================================================================
-- 내가좋아요한 게시물 쿼리
select * from simplerecipe where recipe_id in (select recipe_id from thumbsup where member_id = '123123') order by write_time desc;



select * from simpleRecipe;
select * from simpleRecipe where category = 'beginner' and like_count = (select max(like_count) from simpleRecipe where category = 'beginner');

select max(like_count) from simpleRecipe where category = 'beginner';
update simplerecipe set like_count = 3 where recipe_id=39;
