package web_pjt.service;

import java.sql.*;
import java.util.*;

import web_pjt.dao.CommentDAO;
import web_pjt.dao.DetailItemDAO;
import web_pjt.dao.MemberDAO;
import web_pjt.dao.ThumbsUpDAO;
import web_pjt.model.Comment;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;
import web_pjt.model.ThumbsUp;

public class ThumbsUpService implements Service {
	private ThumbsUpDAO thumbsUpDAO=new ThumbsUpDAO();
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<>();
		Connection conn = (Connection)values.get("conn");
		ThumbsUp thumbsUp = (ThumbsUp)values.get("thumbsUp");
		
		if(thumbsUpDAO.selectOne(conn, thumbsUp)==null) {
			result.put("insert", thumbsUpDAO.insert(conn, thumbsUp));
		}else {
			result.put("delete", thumbsUpDAO.delete(conn, thumbsUp));
		}
		
		return result;
	}
}







