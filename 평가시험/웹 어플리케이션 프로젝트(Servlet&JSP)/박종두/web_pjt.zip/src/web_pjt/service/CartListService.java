package web_pjt.service;

import java.sql.*;
import java.util.*;

import sun.java2d.pipe.SpanShapeRenderer.Simple;
import web_pjt.dao.CartDAO;
import web_pjt.dao.DetailItemDAO;
import web_pjt.dao.MemberDAO;
import web_pjt.dao.SimpleItemDAO;
import web_pjt.model.Cart;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;

public class CartListService implements Service {
	private CartDAO cartDAO=new CartDAO();
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<>();
		Connection conn = (Connection)values.get("conn");
		Cart cart = (Cart)values.get("cart");

		result.put("result", cartDAO.selectAll(conn,cart));
		
		return result;
	}
}







