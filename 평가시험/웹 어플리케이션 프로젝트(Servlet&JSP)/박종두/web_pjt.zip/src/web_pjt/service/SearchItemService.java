package web_pjt.service;

import java.sql.*;
import java.util.*;

import sun.java2d.pipe.SpanShapeRenderer.Simple;
import web_pjt.dao.DetailItemDAO;
import web_pjt.dao.MemberDAO;
import web_pjt.dao.SimpleItemDAO;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;

public class SearchItemService implements Service {
	private SimpleItemDAO simpleItemDAO=new SimpleItemDAO();
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<>();
		Connection conn = (Connection)values.get("conn");
		SimpleItem item = (SimpleItem)values.get("item");
		
		if(item.getCategory()==0) {
			result.put("result", simpleItemDAO.searchAll(conn, item));
			return result;
		}
		
		result.put("result", simpleItemDAO.search(conn, item));
		
		return result;
	}
}







