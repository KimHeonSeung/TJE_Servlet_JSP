package web_pjt.service;

import java.sql.*;
import java.util.*;

import web_pjt.dao.DetailItemDAO;
import web_pjt.dao.MemberDAO;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;

public class AddItemService implements Service {
	private DetailItemDAO detailItemDAO=new DetailItemDAO();
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<>();
		Connection conn = (Connection)values.get("conn");
		DetailItem item = (DetailItem)values.get("item");
				
		result.put("result", detailItemDAO.insert(conn, item));
		
		return result;
	}
}







