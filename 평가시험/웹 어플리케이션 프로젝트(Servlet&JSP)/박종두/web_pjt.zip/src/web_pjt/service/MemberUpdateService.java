package web_pjt.service;

import java.sql.*;
import java.util.*;

import web_pjt.dao.MemberDAO;
import web_pjt.model.Member;

public class MemberUpdateService implements Service {
	private MemberDAO memberDAO = new MemberDAO();

	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<>();
		Connection conn = (Connection) values.get("conn");
		Member member = (Member) values.get("member");

		String type=(String)values.get("type");
		
		if(type.equals("last_access_time"))
			result.put("result", memberDAO.updateLastAT(conn,member));
		else if(type.equals("update_info"))
			result.put("result", memberDAO.updateInfo(conn, member));
		else if(type.equals("update_pw"))
			result.put("result", memberDAO.updatePassword(conn, member));
		
		return result;
	}
}
