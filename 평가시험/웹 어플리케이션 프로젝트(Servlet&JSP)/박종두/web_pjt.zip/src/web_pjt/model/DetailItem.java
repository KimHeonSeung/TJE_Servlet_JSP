package web_pjt.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DetailItem {
	private int item_id;
	private int category;
	private String title;
	private String content;
	private String image;
	private Date write_time;
	private Date update_time;
	private int read_count;
	private int comment_count;
	private int like_count;
	private int number;
	private String price;

	public DetailItem() {
		// TODO Auto-generated constructor stub
	}

	public DetailItem(int item_id, int category, String title, String content, String image, Date write_time,
			Date update_time, int read_count, int comment_count, int like_count, int number, String price) {
		super();
		this.item_id = item_id;
		this.category = category;
		this.title = title;
		this.content = content;
		this.image = image;
		this.write_time = write_time;
		this.update_time = update_time;
		this.read_count = read_count;
		this.comment_count = comment_count;
		this.like_count = like_count;
		this.number = number;
		this.price = price;
	}



	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Date getWrite_time() {
		return write_time;
	}
	
	public String getWrite_timeString() {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		
		return sdf.format(write_time);
	}

	public void setWrite_time(Date write_time) {
		this.write_time = write_time;
	}

	public Date getUpdate_time() {
		return update_time;
	}
	
	public String getUpdate_timeString() {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		
		String s="";
		
		if(update_time==null)
			s="수정 내역 없음";
		else
			s=sdf.format(update_time);
		
		return s;
	}

	public void setUpdate_time(Date update_time) {
		this.update_time = update_time;
	}

	public int getRead_count() {
		return read_count;
	}

	public void setRead_count(int read_count) {
		this.read_count = read_count;
	}

	public int getComment_count() {
		return comment_count;
	}

	public void setComment_count(int comment_count) {
		this.comment_count = comment_count;
	}

	public int getLike_count() {
		return like_count;
	}

	public void setLike_count(int like_count) {
		this.like_count = like_count;
	}
	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(obj instanceof DetailItem) {
			DetailItem detailItem=(DetailItem)obj;
			if(item_id==detailItem.item_id)
				return true;
		}
		
		return false;
	}
}
