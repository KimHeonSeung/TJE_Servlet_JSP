package web_pjt.model;

public class SimpleItem {
	private int item_id;
	private int category;
	private String title;
	private String content;
	private String image;
	private int read_count;
	private int comment_count;
	private int like_count;
	private int number;
	private String price;
	
	public SimpleItem() {
		// TODO Auto-generated constructor stub
	}

	public SimpleItem(int item_id, int category, String title, String content, String image, int read_count,
			int comment_count, int like_count, int number, String price) {
		this.item_id = item_id;
		this.category = category;
		this.title = title;
		this.content = content;
		this.image = image;
		this.read_count = read_count;
		this.comment_count = comment_count;
		this.like_count = like_count;
		this.number = number;
		this.price = price;
	}



	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public int getCategory() {
		return category;
	}
	
	public String getCategoryString() {
		String strCategory="";
		
		if(category==1)
			strCategory="상의";
		else if(category==2)
			strCategory="하의";
		else if(category==3)
			strCategory="악세사리";
		else
			strCategory="기타";
		
		return strCategory;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getRead_count() {
		return read_count;
	}

	public void setRead_count(int read_count) {
		this.read_count = read_count;
	}

	public int getComment_count() {
		return comment_count;
	}

	public void setComment_count(int comment_count) {
		this.comment_count = comment_count;
	}

	public int getLike_count() {
		return like_count;
	}

	public void setLike_count(int like_count) {
		this.like_count = like_count;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	
}
