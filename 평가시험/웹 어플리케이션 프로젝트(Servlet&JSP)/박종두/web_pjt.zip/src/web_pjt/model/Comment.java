package web_pjt.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Comment {
	private int comment_id;
	private int item_id;
	private String member_id;
	private String content;
	private Date write_time;
	
	public Comment() {
		// TODO Auto-generated constructor stub
	}

	public Comment(int comment_id, int item_id, String member_id, String content, Date write_time) {
		super();
		this.comment_id = comment_id;
		this.item_id = item_id;
		this.member_id = member_id;
		this.content = content;
		this.write_time = write_time;
	}

	public int getComment_id() {
		return comment_id;
	}

	public void setComment_id(int comment_id) {
		this.comment_id = comment_id;
	}

	public int getItem_id() {
		return item_id;
	}

	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}

	public String getMember_id() {
		return member_id;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getWrite_time() {
		return write_time;
	}
	
	public String getWrite_timeString() {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		
		return sdf.format(write_time);
	}

	public void setWrite_time(Date write_time) {
		this.write_time = write_time;
	}

}
