package web_pjt.command;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;
import web_pjt.service.MainListService;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberUpdateService;

public class MainCommand extends Command {
	private String formPage="/WEB-INF/forms/main.jsp";
	private String submitPage="/WEB-INF/forms/main.jsp";
	
	private MainListService mlService=new MainListService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		ArrayList<SimpleItem> arrList=null;
		
		try(Connection conn=ConnectionProvider.getConnection()){
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			
			HashMap<String, Object> resultMap=mlService.service(values);
			
			arrList=(ArrayList<SimpleItem>) resultMap.get("mostReadList");
			request.setAttribute("mostReadList", arrList);
			
			arrList=(ArrayList<SimpleItem>) resultMap.get("mostCommentList");
			request.setAttribute("mostCommentList", arrList);
			
			arrList=(ArrayList<SimpleItem>) resultMap.get("mostLikeList");
			request.setAttribute("mostLikeList", arrList);
			
		}catch (Exception e) {
			
		}
		
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
	
		
		return null;
	}

}
