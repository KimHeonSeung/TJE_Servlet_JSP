package web_pjt.command;

import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.sun.org.apache.xpath.internal.operations.Bool;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberRegistService;
import web_pjt.service.MemberUpdateService;

public class PasswordUpdateCommand extends Command {
	private String formPage="/WEB-INF/forms/passwordUpdate.jsp";
	private String submitPage="/WEB-INF/forms/regist.jsp";

	private MemberUpdateService muService=new MemberUpdateService();
	private MemberIDCheckService micService=new MemberIDCheckService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		
		Member login_member=(Member) session.getAttribute("login_member");
		
		String member_id = login_member.getMember_id();
		
		String password=request.getParameter("password");
		
		Member member = new Member();
		member.setMember_id(member_id);
		member.setPassword(password);
		
		boolean result=false;
		
		try(Connection conn=ConnectionProvider.getConnection()){
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("member", member);
			values.put("type", "update_pw");
			
			result=(Boolean)muService.service(values).get("result");
			
			JSONObject obj=new JSONObject();
			
			if (!result) {
				obj.put("result", true);
				response.setContentType("application/x-json; charset=UTF-8");
				response.getWriter().print(obj);
				return null;
			}
			
			obj.put("result", false);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		}catch (Exception e) {
			
		}
		
		return null;
	}
	
	private int intConvertor(String source) {
		int data = 0;
		try {
			data = Integer.parseInt(source);
		} catch (Exception e) {
			;
		}
		return data;
	}
}
