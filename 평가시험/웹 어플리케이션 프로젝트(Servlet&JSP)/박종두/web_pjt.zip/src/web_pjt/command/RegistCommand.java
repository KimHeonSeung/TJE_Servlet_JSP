package web_pjt.command;

import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sun.org.apache.xpath.internal.operations.Bool;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberRegistService;

public class RegistCommand extends Command {
	private String formPage="/WEB-INF/forms/regist.jsp";
	private String submitPage="/WEB-INF/forms/regist.jsp";

	private MemberRegistService mrService=new MemberRegistService();
	private MemberIDCheckService micService=new MemberIDCheckService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String member_id = request.getParameter("member_id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		int gender = intConvertor(request.getParameter("gender"));
		int age = intConvertor(request.getParameter("age"));
		String birth=request.getParameter("birth");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		
		Member member = new Member(member_id, password, name, gender, age, null, tel, address, null, null);
		member.setBirth(birth);
		
		boolean result=false;
		
		try(Connection conn=ConnectionProvider.getConnection()){
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("member", member);
			
			result=(Boolean)micService.service(values).get("result");
			
			JSONObject obj=new JSONObject();
			
			if(result) {
				obj.put("idCheck", true);
				response.setContentType("application/x-json; charset=UTF-8");
				response.getWriter().print(obj);
				return null;
			}
			
			result = (Boolean) mrService.service(values).get("result");
			
			if (!result) {
				obj.put("result", true);
				response.setContentType("application/x-json; charset=UTF-8");
				response.getWriter().print(obj);
				return null;
			}
			
			obj.put("result", false);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		}catch (Exception e) {
			
		}
		
		return null;
	}
	
	private int intConvertor(String source) {
		int data = 0;
		try {
			data = Integer.parseInt(source);
		} catch (Exception e) {
			;
		}
		return data;
	}
}
