package web_pjt.command;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.taglibs.standard.lang.jstl.BooleanLiteral;
import org.json.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.DetailItem;

import web_pjt.service.AddItemService;
import web_pjt.service.DeleteItemService;
import web_pjt.service.ItemViewService;
import web_pjt.service.UpdateItemService;


public class DeleteItemCommand extends Command {
	private String formPage="/WEB-INF/forms/update_item.jsp";
	private String errorPage="/WEB-INF/errors/update_item.jsp";
	
	private DeleteItemService diService=new DeleteItemService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		
		DetailItem item=new DetailItem();
		item.setItem_id(item_id);
		
		try(Connection conn=ConnectionProvider.getConnection()) {
			
			HashMap<String, Object> values=new HashMap<>();
			values.put("conn", conn);
			values.put("item", item);
			
			HashMap<String, Object> resultMap=diService.service(values);
			
			JSONObject obj=new JSONObject();
			
			response.setContentType("application/x-json; charset=UTF-8");
			
			if(!(Boolean)resultMap.get("result")){
				obj.put("deleteCheck", true);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			obj.put("delete", true);
			response.getWriter().print(obj);
			response.getWriter().flush();
			
		}catch (Exception e) {
			// TODO: handle exception
		}

		return null;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {

		
		return null;
	}
}
