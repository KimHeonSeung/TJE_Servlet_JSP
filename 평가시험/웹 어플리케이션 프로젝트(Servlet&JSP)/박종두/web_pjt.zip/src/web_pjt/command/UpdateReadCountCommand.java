package web_pjt.command;



import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.DetailItem;
import web_pjt.service.ItemViewService;



public class UpdateReadCountCommand extends Command {
	private String formPage="/WEB-INF/forms/item_view.jsp";
	private String errorPage="/WEB-INF/errors/item_view.jsp";
	
	private ItemViewService ivService=new ItemViewService();

	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		
		DetailItem item=new DetailItem();
		item.setItem_id(item_id);
		
		try (Connection conn=ConnectionProvider.getConnection()){
			
			HashMap<String, Object> values=new HashMap<>();
			values.put("conn", conn);
			values.put("item", item);
			
			HashMap<String, Object> resultMap=ivService.service(values);
			
			DetailItem result=(DetailItem) resultMap.get("searchedItem");
			
			if(result==null){
				request.setAttribute("errorMsg", "찾을 수 없는 상품 입니다.");
				return errorPage;
			}
			
			System.out.println((DetailItem)resultMap.get("result"));
			
			request.setAttribute("searchedItem", result);
				
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		
		return null;
	}
}
