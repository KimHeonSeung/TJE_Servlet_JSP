package web_pjt.command;

import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.sun.org.apache.xpath.internal.operations.Bool;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberRegistService;
import web_pjt.service.MemberUpdateService;

public class InfoUpdateCommand extends Command {
	private String formPage="/WEB-INF/forms/infoUpdate.jsp";
	private String submitPage="/WEB-INF/forms/regist.jsp";

	private MemberUpdateService muService=new MemberUpdateService();
	private MemberIDCheckService micService=new MemberIDCheckService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		
		Member login_member=(Member) session.getAttribute("login_member");
		
		String member_id = login_member.getMember_id();
		
		String name = request.getParameter("name");
		int gender = intConvertor(request.getParameter("gender"));
		int age = intConvertor(request.getParameter("age"));
		String birth=request.getParameter("birth");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		
		Member member = new Member(member_id, null, name, gender, age, null, tel, address, null, null);
		member.setBirth(birth);
		
		boolean result=false;
		
		try(Connection conn=ConnectionProvider.getConnection()){
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("member", member);
			values.put("type", "update_info");
			
			result=(Boolean)muService.service(values).get("result");
			
			JSONObject obj=new JSONObject();
			
			if (!result) {
				obj.put("result", true);
				response.setContentType("application/x-json; charset=UTF-8");
				response.getWriter().print(obj);
				return null;
			}
			
			session.removeAttribute("login_member");
			
			HashMap<String, Object> resultMap=micService.service(values);
			Member new_member=(Member) resultMap.get("searchedMember");
			
			session.setAttribute("login_member", new_member);
			
			obj.put("result", false);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		}catch (Exception e) {
			
		}
		
		return null;
	}
	
	private int intConvertor(String source) {
		int data = 0;
		try {
			data = Integer.parseInt(source);
		} catch (Exception e) {
			;
		}
		return data;
	}
}
