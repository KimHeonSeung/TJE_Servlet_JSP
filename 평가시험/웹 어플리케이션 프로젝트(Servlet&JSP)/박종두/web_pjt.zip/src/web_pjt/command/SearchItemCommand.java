package web_pjt.command;

import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.mysql.cj.xdevapi.JsonArray;

import sun.java2d.pipe.SpanShapeRenderer.Simple;
import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;
import web_pjt.service.ItemListService;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberUpdateService;
import web_pjt.service.SearchItemService;

public class SearchItemCommand extends Command {
	
	private String formPage="WEB-INF/forms/search_item.jsp";
	
	private SearchItemService siService=new SearchItemService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
	
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String strCategory=request.getParameter("category");
		int category=Integer.parseInt(strCategory);
		String search=request.getParameter("search");
		
		SimpleItem item=new SimpleItem();
		item.setCategory(category);
		item.setTitle(search);
		
		try (Connection conn=ConnectionProvider.getConnection()){
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("item", item);
			
			HashMap<String, Object> resultMap=siService.service(values);
			
			ArrayList<SimpleItem> searchList=(ArrayList<SimpleItem>) resultMap.get("result");
			
			JSONObject obj=new JSONObject();

			response.setContentType("application/x-json; charset=UTF-8");
			
			if(searchList.isEmpty()) {
				obj.put("result", false);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			obj.put("result", true);
			//response.getWriter().print(obj);
			//response.getWriter().flush();
			
			ArrayList<SimpleItem> arrList=new ArrayList<>();
			for (SimpleItem searchItem : searchList) {
				arrList.add(searchItem);
			}
			
			obj.put("simpleList", arrList);
			response.getWriter().print(obj);
			response.getWriter().flush();
			
			//request.setAttribute("searchList", searchList);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
	}

}
