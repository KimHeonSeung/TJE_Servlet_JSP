package web_pjt.command;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Cart;
import web_pjt.model.Comment;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.service.AddCartService;
import web_pjt.service.AddCommentService;
import web_pjt.service.AddItemService;


public class AddCartCommand extends Command {
	
	private AddCartService acService=new AddCartService();

	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return null;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		Member login_member=null;
		String member_id=null;
		try {
			login_member=(Member) session.getAttribute("login_member");
			member_id=login_member.getMember_id();
		} catch (Exception e) {
			
		}
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		String image=request.getParameter("image");
		String title=request.getParameter("title");
		String strCategory=request.getParameter("category");
		int category=Integer.parseInt(strCategory);
		
		Cart cart=new Cart(0, item_id, member_id, image, title, category, null);
		
		
		
		JSONObject obj=new JSONObject();
		
		if(login_member==null) {
			ArrayList<Cart> cartList=(ArrayList<Cart>) session.getAttribute("cart_list");
			
			if(cartList==null) {
				cartList=new ArrayList<Cart>();
				cart.setAdd_time(new Date());
				cartList.add(cart);
			}else {
				cart.setAdd_time(new Date());
				cartList.add(cart);
			}
			
			obj.put("addCartCheck", true);
			response.setContentType("application/x-json; charset=UTF-8");
			try {
				obj.put("addCartCheck", true);
				response.getWriter().print(obj);
			} catch (IOException e) {
				try {
					obj.put("addCartCheck", false);
					response.getWriter().print(obj);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
			session.setAttribute("cart_list", cartList);
			return null;
		}

		boolean result=false;
		
		try(Connection conn=ConnectionProvider.getConnection()) {
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("cart", cart);
			
			HashMap<String, Object> resultMap=acService.service(values);
			
			result=(Boolean) resultMap.get("result");
			
			
			
			obj.put("addCartCheck", result);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
