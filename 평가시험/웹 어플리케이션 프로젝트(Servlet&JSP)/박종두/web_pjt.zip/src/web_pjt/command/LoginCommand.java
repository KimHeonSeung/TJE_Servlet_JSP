package web_pjt.command;

import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberUpdateService;

public class LoginCommand extends Command {
	
	private String formPage = "/WEB-INF/forms/login.jsp";

	private MemberIDCheckService micService=new MemberIDCheckService();
	private MemberUpdateService muService=new MemberUpdateService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String member_id=request.getParameter("id");
		String password=request.getParameter("password");
		String save_member_id = request.getParameter("save_member_id");
		
		Member member=new Member();
		member.setMember_id(member_id);
		member.setPassword(password);
		
		try(Connection conn=ConnectionProvider.getConnection()){
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("member", member);
			
			HashMap<String, Object> resultMap=micService.service(values);
			
			JSONObject obj=new JSONObject();
			
			response.setContentType("application/x-json; charset=UTF-8");
			
			if (!(boolean) resultMap.get("result")) {
				obj.put("idCheck", true);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			Member searchedMember = (Member) resultMap.get("searchedMember");
			boolean isLogin = searchedMember.getPassword().equals(member.getPassword());
			if (!isLogin) {
				obj.put("passwordCheck", true);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			values.put("type", "last_access_time");
			resultMap = muService.service(values);
			if (!(boolean) resultMap.get("result")) {
				obj.put("loginCheck", true);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			HttpSession session = request.getSession();
			searchedMember.setLast_access_time(new java.util.Date());
			session.setAttribute("login_member", searchedMember);
			
			obj.put("login", true);
			response.getWriter().print(obj);
			response.getWriter().flush();
			
			/*
			if (save_member_id != null && save_member_id.equals("true")) {
				response.addCookie(new Cookie("save_member_id", member_id));
				return null;
			}
			else {
				Cookie cookie=new Cookie("save_member_id", "");
				cookie.setMaxAge(0);
				response.addCookie(cookie);
				return null;
			}
			*/
		}catch (Exception e) {

		}
		
		return null;
	}

}
