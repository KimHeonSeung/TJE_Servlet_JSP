package web_pjt.command;



import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Comment;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.ThumbsUp;
import web_pjt.service.CommentListService;
import web_pjt.service.ItemViewService;
import web_pjt.service.ThumbsUpCheckService;
import web_pjt.service.UpdateItemReadCountService;



public class ItemViewCommand extends Command {
	private String formPage="/WEB-INF/forms/item_view.jsp";
	private String errorPage="/WEB-INF/errors/item_view.jsp";
	
	private ItemViewService ivService=new ItemViewService();
	private UpdateItemReadCountService uircService=new UpdateItemReadCountService();
	private CommentListService clService=new CommentListService();
	private ThumbsUpCheckService tucService=new ThumbsUpCheckService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		ArrayList<DetailItem> recent_items=(ArrayList<DetailItem>) session.getAttribute("recent_items");
		
		if(recent_items==null) 
			recent_items=new ArrayList<DetailItem>();
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		Member login_member=(Member) request.getSession().getAttribute("login_member");
		String member_id="";
		if(login_member!=null)
			member_id=login_member.getMember_id();

		DetailItem item=new DetailItem();
		item.setItem_id(item_id);
		
		Comment comment=new Comment();
		comment.setItem_id(item_id);
		
		ThumbsUp thumbsUp=new ThumbsUp(0, item_id, member_id);
		
		try (Connection conn=ConnectionProvider.getConnection()){
			
			HashMap<String, Object> values=new HashMap<>();
			values.put("conn", conn);
			values.put("item", item);
			values.put("comment", comment);
			values.put("thumbsUp", thumbsUp);
			
			HashMap<String, Object> resultMap=uircService.service(values);

			if(!(Boolean)resultMap.get("result")){
				request.setAttribute("errorMsg", "조회수 갱신에서 문제 발생");
				return errorPage;
			}
			
			resultMap=ivService.service(values);
			DetailItem result=(DetailItem) resultMap.get("searchedItem");
			
			if(result==null){
				request.setAttribute("errorMsg", "찾을 수 없는 상품 입니다.");
				return errorPage;
			}
			
			if(recent_items.size()<5) {
				if(recent_items.contains(result)) {
					
				}else {
					recent_items.add(result);
				}
			}else {
				if(recent_items.contains(result)) {
					
				}else {
					recent_items.remove(0);
					recent_items.add(result);
				}
			}
			
			session.setAttribute("recent_items", recent_items);
			
			request.setAttribute("searchedItem", result);
			
			resultMap=clService.service(values);
			ArrayList<Comment> commentList=(ArrayList<Comment>) resultMap.get("result");
			
			request.setAttribute("commentList", commentList);
			
			resultMap=tucService.service(values);
			
			if((Boolean)resultMap.get("thumsUpCheck")==true)
				request.setAttribute("thumsUpCheck", true);
			else
				request.setAttribute("thumsUpCheck", false);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		
		return null;
	}
}
