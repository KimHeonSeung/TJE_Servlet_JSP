package web_pjt.command;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Comment;
import web_pjt.model.DetailItem;
import web_pjt.model.ThumbsUp;
import web_pjt.service.AddCommentService;
import web_pjt.service.AddItemService;
import web_pjt.service.ThumbsUpService;


public class ThumbsUpCommand extends Command {
	
	private ThumbsUpService tuService=new ThumbsUpService();

	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return null;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		String member_id=request.getParameter("member_id");
		
		ThumbsUp thumbsUp=new ThumbsUp(0, item_id, member_id);
		
		boolean result=false;
		try(Connection conn=ConnectionProvider.getConnection()) {
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("thumbsUp", thumbsUp);
			
			HashMap<String, Object> resultMap=tuService.service(values);
			
			JSONObject obj=new JSONObject();
			
			response.setContentType("application/x-json; charset=UTF-8");
			
			try {
				result=(boolean)resultMap.get("insert");
			} catch (Exception e) {
				result=false;
			}
			
			if(result==true) {
				obj.put("thumbsUp", result);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			try {
				result=(boolean)resultMap.get("delete");
			} catch (Exception e) {
				result=false;
			}
			
			if(result==true) {
				obj.put("disThumbsUp", result);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			obj.put("fail", result);
			response.getWriter().print(obj);
			response.getWriter().flush();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
