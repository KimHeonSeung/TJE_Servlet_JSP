package web_pjt.command;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Comment;
import web_pjt.model.DetailItem;
import web_pjt.service.AddCommentService;
import web_pjt.service.AddItemService;


public class AddCommentCommand extends Command {
	
	private AddCommentService acService=new AddCommentService();

	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return null;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String strItem_id=request.getParameter("item_id");
		int item_id=Integer.parseInt(strItem_id);
		String member_id=request.getParameter("member_id");
		String content=request.getParameter("content");
		
		Comment comment=new Comment(0, item_id, member_id, content, null);
		
		boolean result=false;
		try(Connection conn=ConnectionProvider.getConnection()) {
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("comment", comment);
			
			HashMap<String, Object> resultMap=acService.service(values);
			
			result=(Boolean) resultMap.get("result");
			
			JSONObject obj=new JSONObject();
			
			obj.put("commentCheck", result);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
