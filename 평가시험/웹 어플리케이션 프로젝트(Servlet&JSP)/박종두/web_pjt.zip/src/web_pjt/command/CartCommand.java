package web_pjt.command;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Cart;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;
import web_pjt.service.CartListService;
import web_pjt.service.MainListService;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberUpdateService;

public class CartCommand extends Command {
	private String formPage="/WEB-INF/forms/cart.jsp";
	private String submitPage="/WEB-INF/forms/main.jsp";
	
	private CartListService clService=new CartListService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		Member login_member=(Member) session.getAttribute("login_member");
		
		if(login_member==null) {
			return formPage;
		}
		
		String member_id=login_member.getMember_id();
		
		Cart cart=new Cart();
		cart.setMember_id(member_id);
		
		ArrayList<Cart> cartList=null;

		try (Connection conn = ConnectionProvider.getConnection()) {
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("cart", cart);
			
			HashMap<String, Object> resultMap=clService.service(values);
			
			cartList=(ArrayList<Cart>) resultMap.get("result");
			
			request.setAttribute("cart_list", cartList);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
	
		
		return null;
	}

}
