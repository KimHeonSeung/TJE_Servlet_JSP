package web_pjt.command;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import java.util.*;
import java.sql.*;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberUpdateService;

public class LogoutCommand extends Command {
	private String formPage = "/WEB-INF/forms/logout.jsp";
	private String submitPage = "/WEB-INF/submits/logout.jsp";
	private String errorPage = "/WEB-INF/errors/logout.jsp";

	private MemberUpdateService muService = new MemberUpdateService();

	// GET 요청일 경우의 처리 로직을 구현하는 메소드
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	// POST 요청일 경우의 처리 로직을 구현하는 메소드
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		Member member = (Member) session.getAttribute("login_member");

		try (Connection conn = ConnectionProvider.getConnection()) {

			HashMap<String, Object> values = new HashMap<>();
			values.put("conn", conn);
			values.put("member", member);
			values.put("type", "last_access_time");
			HashMap<String, Object> resultMap = muService.service(values);
			
			JSONObject obj=new JSONObject();
			
			response.setContentType("application/x-json; charset=UTF-8");
			
			if (!(boolean) resultMap.get("result")) {
				obj.put("logoutCheck", true);
				response.getWriter().print(obj);
				response.getWriter().flush();
				return null;
			}
			
			obj.put("logout", true);
			response.getWriter().print(obj);
			response.getWriter().flush();
			
			session.removeAttribute("login_member");

		} catch (Exception e) {
			// TODO: handle exception
			e.getStackTrace();
		}

		return null;
	}
}
