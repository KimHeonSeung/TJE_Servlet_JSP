package web_pjt.command;

import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sun.org.apache.xpath.internal.operations.Bool;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.Member;
import web_pjt.service.MemberIDCheckService;
import web_pjt.service.MemberRegistService;

public class UpdateCommand extends Command {
	private String formPage="/WEB-INF/forms/update.jsp";
	private String submitPage="/WEB-INF/submits/regist.jsp";

	private MemberRegistService mrService=new MemberRegistService();
	private MemberIDCheckService micService=new MemberIDCheckService();
	
	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		return null;
	}
	
}
