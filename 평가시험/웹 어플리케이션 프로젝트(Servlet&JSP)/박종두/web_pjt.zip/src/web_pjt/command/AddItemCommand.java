package web_pjt.command;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import web_pjt.jdbc.util.ConnectionProvider;
import web_pjt.model.DetailItem;

import web_pjt.service.AddItemService;


public class AddItemCommand extends Command {
	private String formPage="/WEB-INF/forms/add_item.jsp";
	
	private AddItemService aiService=new AddItemService();

	@Override
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {

		return formPage;
	}

	@Override
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		
		String dirPath=request.getServletContext().getRealPath("/images");
		System.out.println(dirPath);
		File dir=new File(dirPath);
		
		if(!dir.exists())
			dir.mkdirs();
		
		int size=10*1024*1024;
		
		boolean result=false;
		MultipartRequest multipartRequest=null;
		
		try(Connection conn=ConnectionProvider.getConnection()) {
			multipartRequest=new MultipartRequest(request, dirPath, size, "utf-8", new DefaultFileRenamePolicy());
			
			String title=multipartRequest.getParameter("title");
			String content=multipartRequest.getParameter("content");
			String strCategory=multipartRequest.getParameter("category");
			int category=Integer.parseInt(strCategory);
			int number=Integer.parseInt(multipartRequest.getParameter("number"));
			String price=multipartRequest.getParameter("price");
			String imageName=multipartRequest.getFilesystemName("image");
			String orginName=multipartRequest.getOriginalFileName("image");
			
			DetailItem item=new DetailItem(0, category, title, content, imageName, null, null, 0, 0, 0, number, price);
			
			HashMap<String, Object> values=new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("item", item);
			
			HashMap<String, Object> resultMap=aiService.service(values);
			
			result=(Boolean) resultMap.get("result");
			
			JSONObject obj=new JSONObject();
			
			obj.put("insertCheck", result);
			response.setContentType("application/x-json; charset=UTF-8");
			response.getWriter().print(obj);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
}
