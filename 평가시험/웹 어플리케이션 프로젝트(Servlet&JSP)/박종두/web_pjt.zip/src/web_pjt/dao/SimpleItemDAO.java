package web_pjt.dao;

import java.sql.*;
import java.util.*;
import java.util.Date;

import web_pjt.jdbc.util.Closer;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;
import web_pjt.model.SimpleItem;

public class SimpleItemDAO {
	private SimpleItem getInstance(ResultSet rs) throws SQLException {		
		SimpleItem obj = new SimpleItem(
				rs.getInt("item_id"),
				rs.getInt("category"),
				rs.getString("title"),
				rs.getString("content"),				
				rs.getString("image"),
				rs.getInt("read_count"),
				rs.getInt("comment_count"),
				rs.getInt("like_count"),
				rs.getInt("number"),
				rs.getString("price"));
		return obj;
	}
	
	public SimpleItem selectOne(Connection conn, SimpleItem obj) {
		SimpleItem result = null;
		String sql = "select * from simpleitem where item_id = ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			
			rs = pstmt.executeQuery();
			if( rs.next() )
				result = getInstance(rs);
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> selectAll(Connection conn) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);						
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> most_read_count(Connection conn) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem order by read_count desc limit 3";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);						
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> most_comment_count(Connection conn) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem order by comment_count desc limit 3";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);						
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> most_like_count(Connection conn) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem order by like_count desc limit 3";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);						
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> selectCategory(Connection conn, SimpleItem obj) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem where category=?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);		
			pstmt.setInt(1, obj.getCategory());
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> search(Connection conn, SimpleItem obj) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem where category=? and title like ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getCategory());
			pstmt.setString(2, "%"+obj.getTitle()+"%");
			
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<SimpleItem> searchAll(Connection conn, SimpleItem obj) {
		ArrayList<SimpleItem> result = new ArrayList<>();
		String sql = "select * from simpleitem where title like ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+obj.getTitle()+"%");
			
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	private void setPreparedStatement(int index, int value, PreparedStatement pstmt) throws SQLException {
		if( value != 0 )
			pstmt.setInt(index, value);
		else
			pstmt.setNull(index, Types.NULL);
	}

	private void setPreparedStatement(int index, String value, PreparedStatement pstmt) throws SQLException  {
		if( value != null && value.length() > 0 )
			pstmt.setString(index, value);
		else
			pstmt.setNull(index, Types.NULL);
	}
	
	private void setPreparedStatement(int index, Date value, PreparedStatement pstmt) throws SQLException  {
		if( value != null )			
			pstmt.setTimestamp(index, 
					new java.sql.Timestamp(value.getTime()));
		else
			pstmt.setNull(index, Types.NULL);
	}
}













