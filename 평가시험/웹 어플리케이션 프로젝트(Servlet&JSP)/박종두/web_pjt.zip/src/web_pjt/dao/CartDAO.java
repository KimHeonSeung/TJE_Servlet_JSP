package web_pjt.dao;

import java.sql.*;
import java.util.*;
import java.util.Date;

import web_pjt.jdbc.util.Closer;
import web_pjt.model.Cart;
import web_pjt.model.Comment;

public class CartDAO {
	private Cart getInstance(ResultSet rs) throws SQLException {
		Cart obj = new Cart(
				rs.getInt("cart_id"),
				rs.getInt("item_id"),
				rs.getString("member_id"),
				rs.getString("image"),
				rs.getString("title"),
				rs.getInt("category"),
				rs.getTimestamp("add_time"));
		return obj;
	}
	
	public ArrayList<Cart> selectAll(Connection conn, Cart obj) {
		ArrayList<Cart> result = new ArrayList<Cart>();
		String sql = "select * from cart where member_id = ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getMember_id());
			
			rs = pstmt.executeQuery();
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public Cart selectOne(Connection conn, Cart obj) {
		Cart result = null;
		String sql = "select * from cart where item_id = ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			
			rs = pstmt.executeQuery();
			if( rs.next() )
				result = getInstance(rs);
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean insert(Connection conn, Cart obj) {
		boolean result = false;
		String sql = "insert into cart values (null,?,?,?,?,?,now())";
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, obj.getItem_id());
			pstmt.setString(2, obj.getMember_id());
			pstmt.setString(3, obj.getImage());
			pstmt.setString(4, obj.getTitle());
			pstmt.setInt(5, obj.getCategory());
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
		
	public boolean delete(Connection conn, Cart obj) {
		boolean result = false;
		String sql = "delete from cart where item_id = ?";
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, obj.getItem_id());			
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
}













