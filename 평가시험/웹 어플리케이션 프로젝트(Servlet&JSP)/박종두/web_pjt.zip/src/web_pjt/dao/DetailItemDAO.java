package web_pjt.dao;

import java.sql.*;
import java.util.*;
import java.util.Date;
import web_pjt.jdbc.util.Closer;
import web_pjt.model.DetailItem;
import web_pjt.model.Member;

public class DetailItemDAO {
	private DetailItem getInstance(ResultSet rs) throws SQLException {		
		DetailItem obj = new DetailItem(
				rs.getInt("item_id"),
				rs.getInt("category"),
				rs.getString("title"),
				rs.getString("content"),				
				rs.getString("image"),
				rs.getTimestamp("write_time"),
				rs.getTimestamp("update_time"),
				rs.getInt("read_count"),
				rs.getInt("comment_count"),
				rs.getInt("like_count"),
				rs.getInt("number"),
				rs.getString("price"));
		return obj;
	}
	
	public DetailItem selectOne(Connection conn, DetailItem obj) {
		DetailItem result = null;
		String sql = "select * from detailitem where item_id = ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			
			rs = pstmt.executeQuery();
			if( rs.next() )
				result = getInstance(rs);
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public ArrayList<DetailItem> selectAll(Connection conn) {
		ArrayList<DetailItem> result = new ArrayList<>();
		String sql = "select * from detailitem";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);						
			rs = pstmt.executeQuery();
			
			while( rs.next() )
				result.add(getInstance(rs));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean deleteItem(Connection conn, DetailItem obj) {
		boolean result = false;
		String sql = "delete from item where item_id = ?";
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			
			result = pstmt.executeUpdate() == 1 ? true : false;
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
	
	private void setPreparedStatement(int index, int value, PreparedStatement pstmt) throws SQLException {
		if( value != 0 )
			pstmt.setInt(index, value);
		else
			pstmt.setNull(index, Types.NULL);
	}

	private void setPreparedStatement(int index, String value, PreparedStatement pstmt) throws SQLException  {
		if( value != null && value.length() > 0 )
			pstmt.setString(index, value);
		else
			pstmt.setNull(index, Types.NULL);
	}
	
	private void setPreparedStatement(int index, Date value, PreparedStatement pstmt) throws SQLException  {
		if( value != null )			
			pstmt.setTimestamp(index, 
					new java.sql.Timestamp(value.getTime()));
		else
			pstmt.setNull(index, Types.NULL);
	}
	
	public boolean insert(Connection conn, DetailItem obj) {
		boolean result = false;
		String sql = "insert into item values (0,?,?,?,?,now(),null,0,?,?)";
		
		PreparedStatement pstmt = null;		
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			setPreparedStatement(1, obj.getCategory(),pstmt);
			setPreparedStatement(2, obj.getTitle(),pstmt);
			setPreparedStatement(3, obj.getContent(),pstmt);
			setPreparedStatement(4, obj.getImage(),pstmt);
			setPreparedStatement(5, obj.getNumber(), pstmt);
			setPreparedStatement(6, obj.getPrice(), pstmt);

			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean updateLastAT(Connection conn, DetailItem obj) {
		boolean result = false;
		String sql = "update item set update_time = now() where item_id = ?";
		
		PreparedStatement pstmt = null;		
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean updateReadCount(Connection conn, DetailItem obj) {
		boolean result=false;
		String sql = "update item set read_count = read_count+1 where item_id = ?";
		
		PreparedStatement pstmt = null;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			result = pstmt.executeUpdate() == 1 ? true : false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean updateInfo(Connection conn, DetailItem obj) {
		boolean result = false;
		String sql = "update item set category=?,title=?,content=?,image=?,update_time=now(),number=?, price=? where item_id = ?";
		
		PreparedStatement pstmt = null;		
		
		try {
			pstmt = conn.prepareStatement(sql);
			setPreparedStatement(1, obj.getCategory(), pstmt);
			setPreparedStatement(2, obj.getTitle(), pstmt);
			setPreparedStatement(3, obj.getContent(),pstmt);
			setPreparedStatement(4, obj.getImage(),pstmt);
			pstmt.setInt(5, obj.getNumber());
			pstmt.setString(6, obj.getPrice());
			pstmt.setInt(7, obj.getItem_id());
			
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
}













