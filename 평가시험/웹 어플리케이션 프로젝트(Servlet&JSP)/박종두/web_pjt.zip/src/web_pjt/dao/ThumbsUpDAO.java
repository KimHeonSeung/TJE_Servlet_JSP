package web_pjt.dao;

import java.sql.*;
import java.util.*;
import java.util.Date;

import web_pjt.jdbc.util.Closer;
import web_pjt.model.Comment;
import web_pjt.model.ThumbsUp;

public class ThumbsUpDAO {
	private ThumbsUp getInstance(ResultSet rs) throws SQLException {
		ThumbsUp obj = new ThumbsUp(
				rs.getInt("like_id"),
				rs.getInt("item_id"),
				rs.getString("member_id"));
		return obj;
	}
	
	public ThumbsUp selectOne(Connection conn, ThumbsUp obj) {
		ThumbsUp result = null;
		String sql = "select * from like_table where item_id = ? and member_id = ?";
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getItem_id());
			pstmt.setString(2, obj.getMember_id());
			
			rs = pstmt.executeQuery();
			if( rs.next() )
				result = getInstance(rs);
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}

	public boolean insert(Connection conn, ThumbsUp obj) {
		boolean result = false;
		String sql = "insert into like_table values (null,?,?)";
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, obj.getItem_id());
			pstmt.setString(2, obj.getMember_id());		
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
		
	public boolean delete(Connection conn, ThumbsUp obj) {
		boolean result = false;
		String sql = "delete from like_table where member_id = ?";
		
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, obj.getMember_id());			
			
			result = pstmt.executeUpdate() == 1 ? true : false;
			
		} catch (SQLException e) {			
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
}













