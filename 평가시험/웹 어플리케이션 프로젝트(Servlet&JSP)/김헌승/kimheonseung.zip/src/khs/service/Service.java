package khs.service;

import java.util.*;

public interface Service {
	public abstract HashMap<String, Object> service(
			HashMap<String, Object> values);
}
