package carrot.model;

public class ThumbNail {
	private int image_id;
	private String userImgName;
	private String sysImgName;
	private int article_id;
	
	public ThumbNail(int image_id, String userImgName, String sysImgName, int article_id) {
		super();
		this.image_id = image_id;
		this.userImgName = userImgName;
		this.sysImgName = sysImgName;
		this.article_id = article_id;
	}
	public int getImage_id() {
		return image_id;
	}
	public void setImage_id(int image_id) {
		this.image_id = image_id;
	}
	public String getUserImgName() {
		return userImgName;
	}
	public void setUserImgName(String userImgName) {
		this.userImgName = userImgName;
	}
	public String getSysImgName() {
		return sysImgName;
	}
	public void setSysImgName(String sysImgName) {
		this.sysImgName = sysImgName;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	
	

}
