package carrot.model;

public class ItemImage {
	private int image_id;
	private String detailUserImgName;
	private String detailSysImgName;
	private int article_id;

	public ItemImage(int image_id, String detailUserImgName, String detailSysImgName, int article_id) {
		super();
		this.image_id = image_id;
		this.detailUserImgName = detailUserImgName;
		this.detailSysImgName = detailSysImgName;
		this.article_id = article_id;
	}

	public int getImage_id() {
		return image_id;
	}

	public void setImage_id(int image_id) {
		this.image_id = image_id;
	}

	public String getDetailUserImgName() {
		return detailUserImgName;
	}

	public void setDetailUserImgName(String detailUserImgName) {
		this.detailUserImgName = detailUserImgName;
	}

	public String getDetailSysImgName() {
		return detailSysImgName;
	}

	public void setDetailSysImgName(String detailSysImgName) {
		this.detailSysImgName = detailSysImgName;
	}

	public int getArticle_id() {
		return article_id;
	}

	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}

}
