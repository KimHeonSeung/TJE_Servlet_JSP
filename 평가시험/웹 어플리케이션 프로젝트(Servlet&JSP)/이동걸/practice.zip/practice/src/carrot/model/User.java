package carrot.model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class User {
	private String user_id;
	private String password;
	private String nickname;
	private String tel;
	private String location_city;
	private String location_gu;
	private Timestamp regist_date;


	public User() {
	}
	
	public User(String user_id, String password, String nickname, String tel, String location_city,
			String location_gu,Timestamp regist_date) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.nickname = nickname;
		this.tel = tel;
		this.location_city = location_city;
		this.location_gu = location_gu;
		this.regist_date = regist_date;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getTel() {
		return tel;
	}
	public String[] getTelSpilt() {
		String[] telSplit = new String[3];
		telSplit[0] = tel.substring(0, 3);
		telSplit[1] = tel.substring(6, 10);
		telSplit[2] = tel.substring(13);
		
		return telSplit;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	public String getLocation_gu() {
		return location_gu;
	}

	public void setLocation_gu(String location_gu) {
		this.location_gu = location_gu;
	}

	public String getLocation_city() {
		return location_city;
	}

	public void setLocation_city(String location_city) {
		this.location_city = location_city;
	}

	public Timestamp getRegist_date() {
		return regist_date;
	}
	
	public String getRegist_dateString() {
		SimpleDateFormat sdf = 
				new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분");
		return sdf.format(regist_date);
	}

	public void setRegist_date(Timestamp regist_date) {
		this.regist_date = regist_date;
	}

}
