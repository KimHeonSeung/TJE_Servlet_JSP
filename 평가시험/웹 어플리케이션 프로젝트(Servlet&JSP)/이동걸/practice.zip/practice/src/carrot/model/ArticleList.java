package carrot.model;

public class ArticleList {
	private int article_id;
	private String user_id;
	private String nickname;
	private String userImgName;
	private String sysImgName;
	private String category;
	private String title;
	private String location_city;
	private String location_gu;
	private int price;
	private int read_count;
	private int like_count;
	private int comment_count;
	
	public ArticleList(){}
	
	public ArticleList(int article_id, String user_id, String nickname, String userImgName, String sysImgName,
			String category, String title, String location_city, String location_gu, int price, int read_count,
			int like_count, int comment_count) {
		super();
		this.article_id = article_id;
		this.user_id = user_id;
		this.nickname = nickname;
		this.userImgName = userImgName;
		this.sysImgName = sysImgName;
		this.category = category;
		this.title = title;
		this.location_city = location_city;
		this.location_gu = location_gu;
		this.price = price;
		this.read_count = read_count;
		this.like_count = like_count;
		this.comment_count = comment_count;
	}
	
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getUserImgName() {
		return userImgName;
	}
	public void setUserImgName(String userImgName) {
		this.userImgName = userImgName;
	}
	public String getSysImgName() {
		return sysImgName;
	}
	public void setSysImgName(String sysImgName) {
		this.sysImgName = sysImgName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLocation_city() {
		return location_city;
	}
	public void setLocation_city(String location_city) {
		this.location_city = location_city;
	}
	public String getLocation_gu() {
		return location_gu;
	}
	public void setLocation_gu(String location_gu) {
		this.location_gu = location_gu;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getRead_count() {
		return read_count;
	}
	public void setRead_count(int read_count) {
		this.read_count = read_count;
	}
	public int getLike_count() {
		return like_count;
	}
	public void setLike_count(int like_count) {
		this.like_count = like_count;
	}
	public int getComment_count() {
		return comment_count;
	}
	public void setComment_count(int comment_count) {
		this.comment_count = comment_count;
	}
	
}
