package carrot.model;

import java.sql.Timestamp;
import java.util.ArrayList;

public class DetailArticle {
	
	private int article_id;
	private String user_id;
	private String nickname;
	private String category;
	private String title;
	private String content;
	private String city;
	private String gu;
	private Timestamp write_time;
	private int price;
	private int read_count;
	private int like_count;
	private int comment_count;
	
	
	public DetailArticle() {}
	
	public DetailArticle(int article_id, String user_id, String nickname,
			 String category, String title, String content, String city, String gu,
			Timestamp write_time, int price, int read_count, int like_count, int comment_count) {
		super();
		this.article_id = article_id;
		this.user_id = user_id;
		this.nickname = nickname;
		this.category = category;
		this.title = title;
		this.content = content;
		this.city = city;
		this.gu = gu;
		this.write_time = write_time;
		this.price = price;
		this.read_count = read_count;
		this.like_count = like_count;
		this.comment_count = comment_count;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGu() {
		return gu;
	}
	public void setGu(String gu) {
		this.gu = gu;
	}
	public Timestamp getWrite_time() {
		return write_time;
	}
	public void setWrite_time(Timestamp write_time) {
		this.write_time = write_time;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getRead_count() {
		return read_count;
	}
	public void setRead_count(int read_count) {
		this.read_count = read_count;
	}
	public int getLike_count() {
		return like_count;
	}
	public void setLike_count(int like_count) {
		this.like_count = like_count;
	}
	public int getComment_count() {
		return comment_count;
	}
	public void setComment_count(int comment_count) {
		this.comment_count = comment_count;
	}
	
	
}
