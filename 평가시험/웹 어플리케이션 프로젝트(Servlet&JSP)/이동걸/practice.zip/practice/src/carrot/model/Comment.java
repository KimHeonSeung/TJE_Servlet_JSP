package carrot.model;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class Comment {
	private int comment_id;
	private int article_id;
	private String user_id;
	private String nickname;
	private String content;
	private Timestamp write_time;

	public Comment() {}
	
	public Comment(int comment_id, int article_id, String user_id, String nickname, String content,
			Timestamp write_time) {
		super();
		this.comment_id = comment_id;
		this.article_id = article_id;
		this.user_id = user_id;
		this.nickname = nickname;
		this.content = content;
		this.write_time = write_time;
	}

	public int getComment_id() {
		return comment_id;
	}

	public void setComment_id(int comment_id) {
		this.comment_id = comment_id;
	}

	public int getArticle_id() {
		return article_id;
	}

	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}


	public Timestamp getWrite_time() {
		return write_time;
	}
	
	public String getWrite_timeString() {
		SimpleDateFormat sdf = 
				new SimpleDateFormat("MM월 dd일 hh:mm분");
		return sdf.format(write_time);
	}

	public void setWrite_time(Timestamp write_time) {
		this.write_time = write_time;
	}

}
