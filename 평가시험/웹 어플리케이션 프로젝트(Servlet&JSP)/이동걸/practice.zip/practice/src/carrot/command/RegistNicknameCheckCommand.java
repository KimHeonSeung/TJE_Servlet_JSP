package carrot.command;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import carrot.jdbc.util.Closer;
import carrot.jdbc.util.ConnectionProvider;
import carrot.model.User;
import carrot.service.LoginSelectService;

public class RegistNicknameCheckCommand extends Command {

	private LoginSelectService lsService = new LoginSelectService();
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String inputNickname = request.getParameter("nickname");
		
		// 비동기 통신으로 클라이언트에게 전송할 변수
		boolean result = false;
		Connection conn = ConnectionProvider.getConnection();
		User inputUser = new User();
		inputUser.setNickname(inputNickname);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put("conn", conn);
		values.put("model", inputUser);
		
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = lsService.service(values);
		
		response.setContentType("text/plane;charset=utf-8");
		PrintWriter out = null;
		
		try {
			out = response.getWriter();
			if( !(boolean)resultMap.get("resultNick") ) {
				result = true;
			} 
			out.println(result);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Closer.close(conn);
		return null;
	}
	
}
