package carrot.command;

import javax.servlet.http.Cookie;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carrot.jdbc.util.ConnectionProvider;
import carrot.model.User;
import carrot.service.LoginSelectService;
import carrot.service.RegistInsertService;

import java.util.*;
import java.io.IOException;
import java.sql.*;

public class LogoutCommand extends Command {
	private String formPage = "/WEB-INF/forms/main.jsp";

	private LoginSelectService lsService = new LoginSelectService();

	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession(false);
		
		if( session != null ) {
			session.invalidate();
		}
		try {
			response.sendRedirect("../main.carrot");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}
}
