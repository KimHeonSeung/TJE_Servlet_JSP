package carrot.command;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carrot.jdbc.util.ConnectionProvider;
import carrot.model.User;
import carrot.service.LoginSelectService;
import carrot.service.RegistInsertService;

import java.util.*;
import java.io.IOException;
import java.sql.*;

public class LoginCommand extends Command {
	private String formPage = "/WEB-INF/forms/login.jsp";
	private String submitPage = "/WEB-INF/forms/main.jsp";

	private LoginSelectService lsService = new LoginSelectService();

	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}

	// POST 요청일 경우의 처리 로직을 구현하는 메소드
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String user_id = request.getParameter("user_id").trim();
		String password = request.getParameter("password").trim();
		String save_user_id = request.getParameter("save_user_id");
		
		User user = new User(user_id, password, null, null, null, null,null);
		try(Connection conn = ConnectionProvider.getConnection()){
			
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put("conn", conn);
			values.put("model", user);
			HashMap<String, Object> resultMap = lsService.service(values);
			
			if(!(boolean) resultMap.get("result")) {
				request.setAttribute("errorMsg_ID", "존재하지 않는 아이디 입니다.");
				return formPage;
			}
			
			User searchUser = (User)resultMap.get("searchUser");
			boolean isLogin = searchUser.getPassword().equals(password);

			if (!isLogin) {
				request.setAttribute("errorMsg_PASSWORD", "비밀번호가 적절하지 않습니다.");
				return formPage;
			}
			
			HttpSession session = request.getSession();
			session.setAttribute("login_user", searchUser);
			System.out.println(searchUser.getNickname());
			
			
			if( save_user_id != null && save_user_id.equals("true"))
				response.addCookie(new Cookie("save_user_id",user_id));
			else {
				Cookie cookie = new Cookie("save_user_id", "");
				cookie.setMaxAge(0);
				response.addCookie(cookie);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		try {
			response.sendRedirect("./main.carrot");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
