package carrot.command;

import carrot.service.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import carrot.jdbc.util.Closer;
import carrot.jdbc.util.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class DetailArticleCommand extends Command {

	private static final String errorPage = "/WEB-INF/errors/detailArticle.jsp";
	private static final String formPage = "/WEB-INF/forms/detailArticle.jsp";
	private static final String submitPage = "/WEB-INF/forms/detailArticle.jsp";

	DetailArticleSelectService dasService = new DetailArticleSelectService();
	ItemImageSelectService iiService = new ItemImageSelectService();
	ArticleReadCountService arcService = new ArticleReadCountService();
	CommentSelectService csService = new CommentSelectService();
	int article_id = 0;
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		article_id = Integer.parseInt(request.getParameter("article_id"));
		DetailArticle model = new DetailArticle();
		model.setArticle_id(article_id);
		
		HashMap<String, Object> values = new HashMap<>();
		ArrayList<ItemImage> itemImageList = null;
		ArrayList<Comment> commentList = null;
		try(Connection conn = ConnectionProvider.getConnection()){
			values.put("conn", conn);
			values.put("model", model);
			
			model = (DetailArticle)dasService.service(values).get("detailArticle");
			if ( (boolean)arcService.service(values).get("updateResult") )
				System.out.println("00");
			
			itemImageList=(ArrayList<ItemImage>)iiService.service(values).get("itemImageList");
			commentList=(ArrayList<Comment>)csService.service(values).get("commentList");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("commentList", commentList);
		request.setAttribute("detailArticle", model);
		request.setAttribute("itemImageList", itemImageList);
		
		return formPage;
	}

	CommentInsertService ceService = new CommentInsertService();
	
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String user_id = (String)request.getParameter("user_id");
		String strArticle_id = (String)request.getParameter("article_id");
		int article_id = Integer.parseInt(strArticle_id);
		String nickname = (String)request.getParameter("nickname");
		String comment = ((String)request.getParameter("comment")).trim();
		
		Comment model = new Comment( 0, 
				article_id,
				user_id,
				nickname,
				comment, null);
		
		HashMap<String, Object> values = new HashMap<String, Object>();
		boolean result = false;
		try(Connection conn = ConnectionProvider.getConnection()){
			values.put("conn", conn);
			values.put("model",model);
			
			result = (boolean)ceService.service(values).get("result");
		}catch(Exception e) {
			e.printStackTrace();
		}

		try {
			response.sendRedirect("./detail.carrot?article_id="+article_id);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		return null;
	}
}
