package carrot.command;

import carrot.service.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import carrot.jdbc.util.Closer;
import carrot.jdbc.util.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class ArticleWriteCommand extends Command {

	private static final String errorPage = "/WEB-INF/errors/articleWrite.jsp";
	private static final String formPage = "/WEB-INF/forms/articleWrite.jsp";
	private static final String submitPage = "/WEB-INF/submits/articleWrite.jsp";

	ArticleInsertService aiService = new ArticleInsertService();
	ThumbNailInsertService tniService = new ThumbNailInsertService();
	ImagesInsertService iiService = new ImagesInsertService();

	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}
	// form 에서 인코딩 타입(enctype)을 "multipart/form-data"으로
	// 지정했기 때문에 parameter 값을 받을 때 MultiPartRequest 객체로 받아야 함
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User login_user = (User) session.getAttribute("login_user");

		ServletContext context = request.getServletContext();
		String directory = context.getRealPath("/itemImages/");
		int maxSize = 1024 * 1024 * 100;
		String encoding = "UTF-8";
		MultipartRequest mpr = null;
		try {
			mpr = new MultipartRequest(request, directory, maxSize, encoding, new DefaultFileRenamePolicy());
		} catch (IOException e) {
			e.printStackTrace();
		}

		String title = mpr.getParameter("title");
		String category = mpr.getParameter("category");
		String strPrice = mpr.getParameter("price");
		if (strPrice == null || strPrice.equals("") || strPrice.equals("null"))
			strPrice = "0";
		int price = Integer.parseInt(strPrice);
		String location_city = mpr.getParameter("location_city");
		String location_gu = mpr.getParameter("location_gu");
		String content = mpr.getParameter("content");
		

		DetailArticle detailArticle = null;

		detailArticle = new DetailArticle(
				0, 
				login_user.getUser_id(), 
				login_user.getNickname(), 
				category, title,
				content, location_city, location_gu,
				null, price, 0, 0, 0);

		HashMap<String, Object> values = new HashMap<>();
		HashMap<String, Object> resultMap = null;

		DetailArticle searchArticle = null;	
		Connection conn = ConnectionProvider.getConnection();
		try {
			values.put("conn", conn);
			values.put("model", detailArticle);

			resultMap = aiService.service(values);

			// article 테이블로 삽입이 성공했지만
			// detailArticle에 자동으로 갱신 되지 않아 <-- 이게 문제 
			// detailArticle 뷰에 있는 데이터를 읽어오지 못하고 있음.
			// :: 자동으로 갱신되지 않는 이유..? DB 테이블 잘못작성..? 
			// -->> 뷰에 comment_id는 있을 수도있고 없을 수도 있기 때문에 left outer join으로 처리해야 함.
			
			if ((boolean) resultMap.get("result")) {
				searchArticle = (DetailArticle)resultMap.get("searchArticle");
				request.setAttribute("detailArticle", searchArticle);
				System.out.println("Command : " + detailArticle.getTitle());
			} else {
				request.setAttribute("error", "detailArticle 객체-뷰 삽입 실패");
				return errorPage;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String thumbUserImgName = mpr.getOriginalFileName("thumbnailImg");
		String thumbSysImgName = mpr.getFilesystemName("thumbnailImg");

		if (!thumbUserImgName.endsWith(".jpg") && !thumbUserImgName.endsWith(".png")) {
			File file = new File(directory + thumbSysImgName);
			file.delete();
			request.setAttribute("error", "썸네일 : 이미지 파일만 등록할 수 있습니다.");
			return errorPage;
		} else {
			// values에 들어가는 객체 변경 필요 **
			ThumbNail thumbNail = new ThumbNail(
					0, thumbUserImgName, thumbSysImgName, searchArticle.getArticle_id());
			values.put("model", thumbNail);
			if ((boolean)tniService.service(values).get("result")) { 
				request.setAttribute("thumbNail", thumbNail);
			}
		}

		// ItemImages 이미지명 테이블 삽입 및 requuest 객체에 세팅
		
		Enumeration imageNames = mpr.getFileNames();
		String DetailUserImgName = null;
		String DetailSysImgName = null;
		ArrayList<ItemImage> imageList = new ArrayList<ItemImage>();
		
		while (imageNames.hasMoreElements()) {

			String param = (String) imageNames.nextElement();

			if (param.equals("thumbnailImg")) {
				continue;
			} else {
				DetailUserImgName = mpr.getOriginalFileName(param);
				DetailSysImgName = mpr.getFilesystemName(param);
			}
			if (DetailUserImgName == null)
				continue;
			
			if (!DetailUserImgName.endsWith(".jpg") && !DetailUserImgName.endsWith(".png")) {
				File file = new File(directory + DetailSysImgName);
				file.delete();
				request.setAttribute("error", "상세 이미지 : 이미지 파일만 등록할 수 있습니다.");
				return errorPage;
			} else {
				// itemImage 테이블 삽입
				ItemImage itemImage = new ItemImage(
						0, DetailUserImgName, DetailSysImgName, searchArticle.getArticle_id());
				values.put("model", itemImage);
				if ((boolean)iiService.service(values).get("result")) {
					// imageList 는 복수 일 수 있기 때문에
					// list에 반복 돌때 마다 Arraylist에 추가 해두고
					// 반복문이 종료되면 request 객체에 세팅함
					imageList.add(itemImage);
				}
			}
		}
		request.setAttribute("imageList", imageList);
		
		Closer.close(conn);

		return submitPage;
	}
}
