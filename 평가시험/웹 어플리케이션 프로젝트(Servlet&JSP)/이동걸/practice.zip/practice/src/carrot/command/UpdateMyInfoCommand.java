package carrot.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carrot.jdbc.util.ConnectionProvider;

import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import carrot.service.RegistInsertService;
import carrot.service.UserUpdateService;

public class UpdateMyInfoCommand extends Command{

	private static final String errorPage = "/WEB-INF/errors/updateMyInfo.jsp";
	private static final String formPage = "/WEB-INF/forms/updateMyInfo.jsp";
	private static final String submitPage = "/WEB-INF/submits/updateMyInfo.jsp";
	
	private UserUpdateService uuService = new UserUpdateService();
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}
	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		String nickname = request.getParameter("nickname");
		String location_city = request.getParameter("location_city");
		String location_gu = request.getParameter("location_gu");
		System.out.println("password:"+password);
		
		User user = null;
		String msg = null;
		try(Connection conn = ConnectionProvider.getConnection()){
		HashMap<String, Object> values = new HashMap<>();
		values.put("conn", conn);
		user = new User(
				user_id, password, nickname, null, location_city, location_gu,null);
		values.put("model", user);
		
		if ( !(boolean)uuService.service(values).get("result")) {
			msg = user_id + "님 회원정보 수정이 실패하였습니다";
			request.setAttribute("msg",msg);
			return errorPage;
		} else {
			msg = user_id + "님 회원정보 수정이 완료되었습니다";
		}
		}catch(Exception e) {		
			e.printStackTrace();
		}
		request.setAttribute("msg",msg);
		HttpSession session = request.getSession();
		session.invalidate();
		
		return submitPage;
	}
	
}
