package carrot.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carrot.jdbc.util.ConnectionProvider;

import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import carrot.service.MyArticleSelectService;
import carrot.service.RegistInsertService;
import carrot.service.UserSelectService;

public class CheckMyInfoCommand extends Command{

	private static final String errorPage = "/WEB-INF/errors/myInfo.jsp";
	private static final String formPage = "/WEB-INF/forms/myInfo.jsp";
	private static final String submitPage = "/WEB-INF/submits/myInfo.jsp";
	
	private UserSelectService usService = new UserSelectService();
	private MyArticleSelectService masService = new MyArticleSelectService();
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		String user_id = request.getParameter("user_id");
		
		User user = new User();
		user.setUser_id(user_id);
		HashMap<String , Object> values = new HashMap<>();
		ArrayList<SimpleArticle> MyArticleList = null;
		try(Connection conn = ConnectionProvider.getConnection()){
			values.put("conn", conn);
			values.put("model", user);
			
			user = (User)usService.service(values).get("result");
			MyArticleList = 
					(ArrayList<SimpleArticle>)masService.service(values).get("MyArticleList");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		HttpSession session = request.getSession();
		String[] telSplit = user.getTelSpilt();
		session.setAttribute("telSplit", telSplit );
		request.setAttribute("MyArticleList", MyArticleList);
		
		return formPage;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		/*
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		String nickname = request.getParameter("nickname");
		String tel1 = request.getParameter("tel1");
		String tel2 = request.getParameter("tel2");
		String tel3 = request.getParameter("tel3");
		String tel = String.format("%s - %s - %s", tel1,tel2,tel3);
		String location_city = request.getParameter("location_city");
		String location_gu = request.getParameter("location_gu");
		
		User user = null;
		
		try(Connection conn = ConnectionProvider.getConnection()){
		HashMap<String, Object> values = new HashMap<>();
		values.put("conn", conn);
		user = new User(
				user_id, password, nickname, tel, location_city, location_gu,null);
		values.put("model", user);
		
		HashMap<String, Object> resultMap = riService.service(values);
		if ( !(boolean)resultMap.get("resultRegist"))
			return errorPage;
		
		}catch(Exception e) {		
			e.printStackTrace();
		}
		request.setAttribute("regist_user", user);
		*/
		
		return submitPage;
	}
	
}
