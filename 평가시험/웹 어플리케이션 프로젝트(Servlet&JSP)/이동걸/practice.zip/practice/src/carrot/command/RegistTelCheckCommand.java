package carrot.command;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import carrot.jdbc.util.ConnectionProvider;
import carrot.model.User;
import carrot.service.LoginSelectService;

public class RegistTelCheckCommand extends Command {

	private LoginSelectService lsService = new LoginSelectService();
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String inputTel = request.getParameter("tel");
		
		// 비동기 통신으로 클라이언트에게 전송할 변수
		boolean result = false;
		User inputUser = null;
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		try(Connection conn = ConnectionProvider.getConnection()){
		inputUser = new User();
		inputUser.setTel(inputTel);
		
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put("conn", conn);
		values.put("model", inputUser);
		
		
		resultMap = lsService.service(values);
		} catch(Exception e) {
			e.printStackTrace();
		}
		response.setContentType("text/plane;charset=utf-8");
		PrintWriter out = null;
		
		try {
			out = response.getWriter();
			String[] telSplit = inputUser.getTelSpilt();
			try {
				for( String tel : telSplit ) {
					Integer.parseInt(tel);
				}
			}catch(Exception e) {
				out.println("핸드폰 번호는 숫자만 입력가능합니다.");
				out.flush();
				return null;
			}
			
			if( !(boolean)resultMap.get("resultTel") ) {
				result = true;
			} 
			out.println(result);
			out.flush();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
