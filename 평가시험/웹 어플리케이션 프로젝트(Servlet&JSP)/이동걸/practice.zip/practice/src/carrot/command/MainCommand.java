package carrot.command;
import java.sql.*;
import java.util.*;
import carrot.model.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import carrot.jdbc.util.ConnectionProvider;
import carrot.service.LoveSelectService;
import carrot.service.MainArticleSelectService;

public class MainCommand extends Command{
	
	private static final String formPage = "/WEB-INF/forms/main.jsp";
	
	MainArticleSelectService masService = new MainArticleSelectService(); 
	LoveSelectService lsService = new LoveSelectService();
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		
		HashMap<String, Object> values = new HashMap<>();
		ArrayList<SimpleArticle> articleList = null;
		HashMap<Integer,String> interestMap = null;
		HttpSession session = request.getSession();
		User login_user = (User)session.getAttribute("login_user");
			
		try(Connection conn = ConnectionProvider.getConnection()){
			values.put("conn", conn);
			articleList = 
					(ArrayList<SimpleArticle>)masService.service(values).get("articleList");
			values.put("model", login_user);
			
			
			if ( login_user != null ) {
				values.put("model", login_user);
				interestMap = (HashMap<Integer,String>)lsService.service(values).get("result");
				request.setAttribute("interestMap", interestMap);
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		request.setAttribute("articleList", articleList);
		
		return formPage;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

}
