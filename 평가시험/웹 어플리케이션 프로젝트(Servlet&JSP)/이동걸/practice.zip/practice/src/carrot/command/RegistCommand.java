package carrot.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import carrot.jdbc.util.ConnectionProvider;

import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import carrot.service.RegistInsertService;
import carrot.service.RegistSelectService;

public class RegistCommand extends Command{

	private static final String errorPage = "/WEB-INF/errors/regist.jsp";
	private static final String formPage = "/WEB-INF/forms/regist.jsp";
	private static final String submitPage = "/WEB-INF/submits/regist.jsp";
	
	private RegistInsertService riService = new RegistInsertService();
	private RegistSelectService rsService = new RegistSelectService();
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String user_id = request.getParameter("user_id");
		String password = request.getParameter("password");
		String nickname = request.getParameter("nickname");
		String tel1 = request.getParameter("tel1");
		String tel2 = request.getParameter("tel2");
		String tel3 = request.getParameter("tel3");
		String tel = String.format("%s - %s - %s", tel1,tel2,tel3);
		String location_city = request.getParameter("location_city");
		String location_gu = request.getParameter("location_gu");
		
		User user = null;
		HashMap<String, Object> values = new HashMap<>();
		try(Connection conn = ConnectionProvider.getConnection()){
		values.put("conn", conn);
		user = new User(
				user_id, password, nickname, tel, location_city, location_gu,null);
		values.put("model", user);
		
		HashMap<String, Object> resultMap = riService.service(values);
		if ( !(boolean)resultMap.get("resultRegist"))
			return errorPage;
		
		request.setAttribute("regist_user", rsService.service(values).get("searchUser"));
		}catch(Exception e) {		
			e.printStackTrace();
		}
		
		return submitPage;
	}
	
}
