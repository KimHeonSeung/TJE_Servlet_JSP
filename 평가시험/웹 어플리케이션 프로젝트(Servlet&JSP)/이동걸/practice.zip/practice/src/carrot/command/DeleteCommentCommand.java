package carrot.command;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import carrot.jdbc.util.Closer;
import carrot.jdbc.util.ConnectionProvider;
import carrot.model.Comment;
import carrot.model.User;
import carrot.service.CommentDeleteService;
import carrot.service.LoginSelectService;

public class DeleteCommentCommand extends Command {
	
	
	CommentDeleteService cdServce = new CommentDeleteService();
	
	
	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return null;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		int comment_id = Integer.parseInt(request.getParameter("comment_id"));
		
		// 비동기 통신으로 클라이언트에게 전송할 변수
		boolean result = false;
		Connection conn = ConnectionProvider.getConnection();
		Comment model = new Comment(comment_id, 0, null, null, null, null);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put("conn", conn);
		values.put("model", model);
		
		if( (boolean)cdServce.service(values).get("result") )
			result = true;

		response.setContentType("text/plane;charset=utf-8");
		PrintWriter out = null;
		
		try {
			out = response.getWriter();
			out.println(result);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Closer.close(conn);
		return null;
	}
	
}
