package carrot.command;

import carrot.service.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import carrot.jdbc.util.Closer;
import carrot.jdbc.util.ConnectionProvider;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.*;
import carrot.model.*;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class DeleteLoveCommand extends Command {

	private static final String errorPage = "/WEB-INF/errors/articleWrite.jsp";
	private static final String formPage = "/WEB-INF/forms/articleWrite.jsp";
	private static final String submitPage = "/WEB-INF/submits/articleWrite.jsp";

	LoveDeleteService ldService = new LoveDeleteService();

	protected String processForm(HttpServletRequest request, HttpServletResponse response) {
		return formPage;
	}

	protected String processSubmit(HttpServletRequest request, HttpServletResponse response) {
		String strArticle_id = request.getParameter("article_id");
		int article_id = Integer.parseInt(strArticle_id);
		String user_id = request.getParameter("user_id");
		
		boolean result = false;
		
		Interest model = new Interest(user_id, article_id);

		try(Connection conn = ConnectionProvider.getConnection()){
		
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put("conn", conn);
		values.put("model", model);
		
		if((boolean)ldService.service(values).get("result"))
			result =true;
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		response.setContentType("text/plane;charset=utf-8");
		PrintWriter out = null;
		
		try {
			out = response.getWriter();
			out.println(result);
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}
}
