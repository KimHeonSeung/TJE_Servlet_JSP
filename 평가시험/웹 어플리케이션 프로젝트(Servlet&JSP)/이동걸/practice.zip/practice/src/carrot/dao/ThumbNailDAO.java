package carrot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import carrot.jdbc.util.Closer;
import carrot.model.ItemImage;
import carrot.model.SimpleArticle;
import carrot.model.ThumbNail;

public class ThumbNailDAO {
	private ThumbNail getInstance(ResultSet rs) {
		ThumbNail obj = null;
		
		try {
			obj = new ThumbNail(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getInt(4));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj; 
	}
	
	public ArrayList<ThumbNail> selectAll(Connection conn){
		ArrayList<ThumbNail> imageList = new ArrayList<ThumbNail>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from thumbNail";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				imageList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);
		
		return imageList; 
	}
	
	public boolean insert(Connection conn, ThumbNail obj) {
		PreparedStatement pstmt = null;
		boolean result = false;
		String sql = "insert into thumbNail values (0,?,?,?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getUserImgName());
			pstmt.setString(2, obj.getSysImgName());
			pstmt.setInt(3, obj.getArticle_id());

			if( pstmt.executeUpdate() == 1)
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);

		return result;
	}
	
}
