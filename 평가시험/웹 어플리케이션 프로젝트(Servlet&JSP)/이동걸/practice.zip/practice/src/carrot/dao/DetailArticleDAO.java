package carrot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import carrot.jdbc.util.Closer;
import carrot.model.DetailArticle;
import carrot.model.ItemImage;
import carrot.model.SimpleArticle;

public class DetailArticleDAO {
	
	private DetailArticle getInstance(ResultSet rs) {
		DetailArticle obj = null;
		
		try {
				obj = new DetailArticle(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6),
						rs.getString(7),
						rs.getString(8),
						rs.getTimestamp(9),
						rs.getInt(10),
						rs.getInt(11),
						rs.getInt(12),
						rs.getInt(13));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj; 
	}
	
	public DetailArticle selectOne(Connection conn, DetailArticle model) {
		DetailArticle obj = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = 
				"select * from detailArticle where title = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getTitle());
			rs = pstmt.executeQuery();
			if( rs.next() ) 
				obj = getInstance(rs);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);

		return obj;
	}
	
	public DetailArticle selectById(Connection conn, DetailArticle model) {
		DetailArticle obj = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = 
				"select * from detailArticle where article_id = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, model.getArticle_id());
			rs = pstmt.executeQuery();
			if( rs.next() ) 
				obj = getInstance(rs);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);

		return obj;
	}
	
	
	public boolean insert(Connection conn,DetailArticle obj){
		boolean result = false;
		PreparedStatement pstmt = null;
		String sql = "insert into article values"
				+ " (0,?,?,?,?,?,?,?,now(),0,0)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getUser_id());
			pstmt.setString(2, obj.getCategory());
			pstmt.setString(3, obj.getTitle());
			pstmt.setString(4, obj.getContent());
			pstmt.setInt(5, obj.getPrice());
			pstmt.setString(6, obj.getCity());
			pstmt.setString(7, obj.getGu());
			
			if( pstmt.executeUpdate() == 1) {
				result = true;
				System.out.println("article 테이블 삽입 성공");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result; 
	}
	public boolean updateReadCount(Connection conn,DetailArticle obj){
		boolean result = false;
		PreparedStatement pstmt = null;
		String sql =" update article set read_count=read_count+1 where article_id=? ";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getArticle_id());
			
			if( pstmt.executeUpdate() == 1) 
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result; 
	}
	
}
