package carrot.dao;
import java.util.*;
import java.sql.*;

import carrot.jdbc.util.Closer;
import carrot.model.*;

public class SimpleArticleDAO {
	
	private SimpleArticle getInstance(ResultSet rs) {
		SimpleArticle obj = null;
		
		try {
			obj = new SimpleArticle(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6),
						rs.getString(7),
						rs.getString(8),
						rs.getString(9),
						rs.getInt(10),
						rs.getInt(11),
						rs.getInt(12),
						rs.getInt(13));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj; 
	}
	public ArrayList<SimpleArticle> selectByUser(Connection conn,User user){
		ArrayList<SimpleArticle> articleList = new ArrayList<SimpleArticle>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from simpleArticle where user_id=?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUser_id());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				articleList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);
		
		return articleList; 
	}
	
	
	public ArrayList<SimpleArticle> selectAll(Connection conn){
		ArrayList<SimpleArticle> articleList = new ArrayList<SimpleArticle>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from simpleArticle order by like_count desc";
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				articleList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);
		
		return articleList; 
	}
	
	public ArrayList<SimpleArticle> selectTitle(Connection conn, SimpleArticle model) {
		ArrayList<SimpleArticle> articleList = new ArrayList<SimpleArticle>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = 
				"select * from simpleArticle where title like ? order by like_count desc";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, '%' + model.getTitle() + '%');
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				articleList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);

		return articleList;
	}
	
	public ArrayList<SimpleArticle> selectCity(Connection conn, SimpleArticle model) {
		ArrayList<SimpleArticle> articleList = new ArrayList<SimpleArticle>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from simpleArticle where city = ? order by like_count desc";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getLocation_city());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				articleList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);

		return articleList;
	}
	
	public ArrayList<SimpleArticle> selectGu(Connection conn, SimpleArticle model) {
		ArrayList<SimpleArticle> articleList = new ArrayList<SimpleArticle>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from simpleArticle where gu = ? order by like_count desc";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getLocation_gu());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				articleList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);

		return articleList;
	}
	
}
