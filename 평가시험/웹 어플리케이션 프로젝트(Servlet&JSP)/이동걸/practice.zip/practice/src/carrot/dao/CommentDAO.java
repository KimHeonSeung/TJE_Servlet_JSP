package carrot.dao;

import carrot.jdbc.util.Closer;
import carrot.model.Comment;
import carrot.model.DetailArticle;
import carrot.model.SimpleArticle;
import java.sql.*;
import java.util.ArrayList;

public class CommentDAO {
	
	private Comment getInstance(ResultSet rs) {
		Comment comment = null;
		try {
			comment = new Comment(
					rs.getInt(1),
					rs.getInt(2),
					rs.getString(3),
					rs.getString(4),
					rs.getString(5),
					rs.getTimestamp(6));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return comment;
	}
	
	public ArrayList<Comment> select(Connection conn, DetailArticle obj){
		ArrayList<Comment> commentList = new ArrayList<Comment>();
		
		String sql = "select * from comment where article_id = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getArticle_id());
			rs = pstmt.executeQuery();
			
			while( rs.next())
				commentList.add(getInstance(rs));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return commentList;
	}
	
	public boolean insert(Connection conn, Comment obj){
		boolean result = false;
		
		String sql = "insert into comment values (0,?,?,?,?,now())";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getArticle_id());
			pstmt.setString(2, obj.getUser_id());
			pstmt.setString(3, obj.getNickname());
			pstmt.setString(4, obj.getContent());
			
			if (pstmt.executeUpdate() == 1 )
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean delete(Connection conn, Comment obj){
		boolean result = false;
		
		String sql = "delete from comment where comment_id = ?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getComment_id());
			
			if (pstmt.executeUpdate() == 1 )
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result;
	}
}
