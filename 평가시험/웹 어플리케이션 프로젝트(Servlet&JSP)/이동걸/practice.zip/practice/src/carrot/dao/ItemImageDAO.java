package carrot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import carrot.jdbc.util.Closer;
import carrot.model.DetailArticle;
import carrot.model.ItemImage;
import carrot.model.SimpleArticle;

public class ItemImageDAO {
	private ItemImage getInstance(ResultSet rs) {
		ItemImage obj = null;
		
		try {
				obj = new ItemImage(
						rs.getInt(1),
						rs.getString(2),
						rs.getString(3),
						rs.getInt(4));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return obj; 
	}
	
	public ArrayList<ItemImage> selectAll(Connection conn,DetailArticle obj){
		ArrayList<ItemImage> imageList = new ArrayList<ItemImage>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from ItemImage where article_id = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getArticle_id());
			rs = pstmt.executeQuery();
			while( rs.next() ) {
				imageList.add(getInstance(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(rs);
		Closer.close(pstmt);
		
		return imageList; 
	}
	
	public boolean insert(Connection conn, ItemImage model) {
		PreparedStatement pstmt = null;
		boolean result = false;
		String sql = "insert into ItemImage values (0,?,?,?)";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getDetailUserImgName());
			pstmt.setString(2, model.getDetailSysImgName());
			pstmt.setInt(3, model.getArticle_id());

			if( pstmt.executeUpdate() == 1)
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);

		return result;
	}
	
}
