package carrot.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import carrot.jdbc.util.Closer;
import carrot.model.*;

public class UserDAO {
		
	private User getInstance(ResultSet rs) {
		User user = null;
		try {
			user = new User(
					rs.getString(1),
					rs.getString(2),
					rs.getString(3),
					rs.getString(4),
					rs.getString(5),
					rs.getString(6),
					rs.getTimestamp(7));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return user;
	}	
	
	public boolean insert(Connection conn, User model) {
		boolean result = false;
		String sql = "insert into user values(?,?,?,?,?,?,now())";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getUser_id());
			pstmt.setString(2, model.getPassword());
			pstmt.setString(3, model.getNickname());
			pstmt.setString(4, model.getTel());
			pstmt.setString(5, model.getLocation_city());
			pstmt.setString(6, model.getLocation_gu());
			if(pstmt.executeUpdate() == 1)
				result= true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
	
	public User selectLogin(Connection conn, User model) {
		User user = null;
		String sql = "select * from user where user_id = ? ";
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getUser_id());
			rs = pstmt.executeQuery();
			
			if(rs.next()) { 
				user = getInstance(rs);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		Closer.close(rs);
		
		return user;
	}
	
	public User selectNickname(Connection conn, User model) {
		User user = null;
		String sql = "select * from user where nickname = ? ";
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getNickname());
			rs = pstmt.executeQuery();
			
			if(rs.next()) { 
				user = getInstance(rs);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		Closer.close(rs);
		
		return user;
	}
	public User selectTel(Connection conn, User model) {
		User user = null;
		String sql = "select * from user where tel = ? ";
		
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getTel());
			rs = pstmt.executeQuery();
			
			if(rs.next()) { 
				user = getInstance(rs);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		Closer.close(rs);
		
		return user;
	}
	
	public boolean update(Connection conn, User model) {
		boolean result = false;
		String sql = "update user set password=?, nickname=?, location_city=?, location_gu=? where user_id=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, model.getPassword());
			pstmt.setString(2, model.getNickname());
			pstmt.setString(3, model.getLocation_city());
			pstmt.setString(4, model.getLocation_gu());
			pstmt.setString(5, model.getUser_id());

			if(pstmt.executeUpdate() == 1)
				result= true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(pstmt);
		
		return result;
	}
}
