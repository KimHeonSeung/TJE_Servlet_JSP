package carrot.dao;

import carrot.jdbc.util.Closer;
import carrot.model.Comment;
import carrot.model.DetailArticle;
import carrot.model.Interest;
import carrot.model.SimpleArticle;
import carrot.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class InterestDAO {
	
	private Interest getInstance(ResultSet rs) {
		Interest interest = null;
		try {
			interest = new Interest(
					rs.getString(1),
					rs.getInt(2)
					);
					
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return interest;
	}
	
	public int selectLove(Connection conn, SimpleArticle obj){
		int result = 0;
		
		String sql = "select count(*) from interest where article_id = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, obj.getArticle_id());
			rs = pstmt.executeQuery();
			
			if (rs.next())
				result = rs.getInt(1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return result;
	}
	
	public HashMap<Integer,String> select(Connection conn, User obj){
		HashMap<Integer,String> interestMap = new HashMap<Integer,String>();
		
		String sql = "select * from interest where user_id = ?";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getUser_id());
			rs = pstmt.executeQuery();
			
			while( rs.next())
				interestMap.put(rs.getInt(2),rs.getString(1));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Closer.close(rs);
		Closer.close(pstmt);
		
		return interestMap;
	}
	
	public boolean insert(Connection conn, Interest obj){
		boolean result = false;
		
		String sql = "insert into interest values (?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getUser_id());
			pstmt.setInt(2, obj.getArticle_id());
			
			if (pstmt.executeUpdate() == 1 )
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result;
	}
	
	public boolean delete(Connection conn, Interest obj){
		boolean result = false;
		
		String sql = "delete from interest where user_id=? and article_id=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, obj.getUser_id());
			pstmt.setInt(2, obj.getArticle_id());
			
			if (pstmt.executeUpdate() != 0 )
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Closer.close(pstmt);
		
		return result;
	}
}
