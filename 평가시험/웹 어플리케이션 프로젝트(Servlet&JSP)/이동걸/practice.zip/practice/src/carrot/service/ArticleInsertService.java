package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.DetailArticleDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.model.*;
public class ArticleInsertService implements Service {
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		DetailArticle model = (DetailArticle) values.get("model");
		
		DetailArticleDAO detailArticleDAO = new DetailArticleDAO();
		
		result.put("result",detailArticleDAO.insert(conn,model));
		result.put("searchArticle",detailArticleDAO.selectOne(conn,model));
		
		return result;
	}

}
