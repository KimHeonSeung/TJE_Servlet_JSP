package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.CommentDAO;
import carrot.dao.DetailArticleDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.model.*;
public class CommentSelectService implements Service {
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		DetailArticle model = (DetailArticle) values.get("model");
		
		CommentDAO commentDAO = new CommentDAO();
		
		result.put("commentList",commentDAO.select(conn,model));
		 
		return result;
	}

}
