package carrot.service;
import carrot.dao.ThumbNailDAO;
import carrot.model.ThumbNail;
import java.util.ArrayList;
import java.util.HashMap;
import java.sql.*;
import carrot.dao.SimpleArticleDAO;
import carrot.dao.UserDAO;
import carrot.model.*;

public class ThumbNailSelectService implements Service {

	private UserDAO userDAO = new UserDAO();
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();

		Connection conn = (Connection) values.get("conn");
				
		ThumbNailDAO thumbNailDAO = new ThumbNailDAO();
		ArrayList<ThumbNail> thumbNailList =
				(ArrayList<ThumbNail>)thumbNailDAO.selectAll(conn);
		
		result.put("thumbNailList", thumbNailList);
		
		return result;
	}

}
