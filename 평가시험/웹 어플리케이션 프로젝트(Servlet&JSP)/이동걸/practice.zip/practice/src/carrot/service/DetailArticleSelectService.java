package carrot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.sql.*;

import carrot.dao.DetailArticleDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.dao.UserDAO;
import carrot.model.*;

public class DetailArticleSelectService implements Service {

	private UserDAO userDAO = new UserDAO();
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();

		Connection conn = (Connection) values.get("conn");
		DetailArticle model = (DetailArticle)values.get("model");
		DetailArticleDAO detailArticleDAO = new DetailArticleDAO();
		
		DetailArticle detailArticle =
				(DetailArticle)detailArticleDAO.selectById(conn, model);
		
		result.put("detailArticle", detailArticle);
		
		return result;
	}

}
