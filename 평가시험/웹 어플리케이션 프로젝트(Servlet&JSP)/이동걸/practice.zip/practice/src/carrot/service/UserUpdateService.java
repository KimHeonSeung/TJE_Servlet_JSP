package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.UserDAO;
import carrot.model.*;
public class UserUpdateService implements Service {

	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		User model = (User) values.get("model");
		
		UserDAO userDAO = new UserDAO();
		
		
		result.put("result", userDAO.update(conn,model));


		
		return result;
	}

}
