package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.UserDAO;
import carrot.model.*;
public class RegistSelectService implements Service {

	private UserDAO userDAO = new UserDAO();
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		User model = (User) values.get("model");
		
		result.put("searchUser", userDAO.selectLogin(conn, model));
		
		return result;
	}

}
