package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.CommentDAO;
import carrot.dao.DetailArticleDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.model.*;
public class CommentInsertService implements Service {
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		Comment model = (Comment) values.get("model");
		
		CommentDAO commentDAO = new CommentDAO();
		
		result.put("result",commentDAO.insert(conn,model));
		 
		return result;
	}

}
