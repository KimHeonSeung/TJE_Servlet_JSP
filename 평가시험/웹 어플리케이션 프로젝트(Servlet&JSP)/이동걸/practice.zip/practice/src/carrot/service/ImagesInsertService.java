/**
 * 
 */
package carrot.service;

import java.sql.Connection;
import java.util.HashMap;

import carrot.dao.ItemImageDAO;
import carrot.model.ItemImage;


public class ImagesInsertService {

	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		ItemImage model = (ItemImage) values.get("model");
		
		ItemImageDAO ItemImagesDAO = new ItemImageDAO();
		
		result.put("result",ItemImagesDAO.insert(conn,model));
		
		return result;
	}
}
