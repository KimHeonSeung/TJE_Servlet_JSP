/**
 * 
 */
package carrot.service;

import java.sql.Connection;
import java.util.HashMap;

import carrot.dao.ItemImageDAO;
import carrot.dao.ThumbNailDAO;
import carrot.model.ItemImage;
import carrot.model.ThumbNail;


public class ThumbNailInsertService {

	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		ThumbNail model = (ThumbNail) values.get("model");
		
		ThumbNailDAO thumbNailDAO = new ThumbNailDAO();
		
		result.put("result",thumbNailDAO.insert(conn,model));
		
		return result;
	}
}
