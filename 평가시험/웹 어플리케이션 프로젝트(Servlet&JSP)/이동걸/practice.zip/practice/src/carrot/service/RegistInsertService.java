package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.UserDAO;
import carrot.model.*;
public class RegistInsertService implements Service {

	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		Connection conn = (Connection) values.get("conn");
		User model = (User) values.get("model");
		
		UserDAO userDAO = new UserDAO();
		if( userDAO.insert(conn,model) ) {
			result.put("resultRegist", true);
		} else {
			
		}
		
		return result;
	}

}
