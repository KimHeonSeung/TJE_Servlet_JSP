package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.DetailArticleDAO;
import carrot.dao.InterestDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.model.*;
public class LoveInsertService implements Service {
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		
		Connection conn = (Connection) values.get("conn");
		Interest model = (Interest) values.get("model");
		
		InterestDAO interestDAO = new InterestDAO();
		
		result.put("result",interestDAO.insert(conn,model));
		
		return result;
	}

}
