package carrot.service;

import java.util.HashMap;
import java.sql.*;

import carrot.dao.DetailArticleDAO;
import carrot.dao.InterestDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.model.*;
public class LoveSelectService implements Service {
	
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		
		Connection conn = (Connection) values.get("conn");
		User model = (User) values.get("model");
		
		InterestDAO interestDAO = new InterestDAO();
		
		result.put("result",interestDAO.select(conn, model));
		
		return result;
	}

}
