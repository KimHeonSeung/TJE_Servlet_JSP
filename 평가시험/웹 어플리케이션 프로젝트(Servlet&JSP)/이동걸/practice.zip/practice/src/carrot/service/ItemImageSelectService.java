package carrot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.sql.*;

import carrot.dao.DetailArticleDAO;
import carrot.dao.ItemImageDAO;
import carrot.dao.SimpleArticleDAO;
import carrot.dao.UserDAO;
import carrot.model.*;

public class ItemImageSelectService implements Service {

	private UserDAO userDAO = new UserDAO();
	public HashMap<String, Object> service(HashMap<String, Object> values) {
		HashMap<String, Object> result = new HashMap<String, Object>();

		Connection conn = (Connection) values.get("conn");
		DetailArticle model = (DetailArticle)values.get("model");
		
		ItemImageDAO itemImageDAO = new ItemImageDAO();
		
		ArrayList<ItemImage> itemImageList =
				(ArrayList<ItemImage>)itemImageDAO.selectAll(conn, model);
		
		result.put("itemImageList", itemImageList);
		
		return result;
	}

}
